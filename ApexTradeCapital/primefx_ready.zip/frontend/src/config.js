export const API_BASE_URL = "https://PrimeFX-backend.onrender.com/api";


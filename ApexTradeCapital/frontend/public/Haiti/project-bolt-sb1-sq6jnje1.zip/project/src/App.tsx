import React from 'react';
import { Phone, Mail, MapPin, Calendar, User, Briefcase, GraduationCap, Award, Users, Zap, Target, Settings } from 'lucide-react';

function App() {
  const ProgressBar = ({ label, percentage }: { label: string; percentage: number }) => (
    <div className="mb-3">
      <div className="flex justify-between mb-1">
        <span className="text-sm font-medium text-gray-700">{label}</span>
        <span className="text-sm text-gray-600">{percentage}%</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-2">
        <div 
          className="bg-blue-800 h-2 rounded-full transition-all duration-300"
          style={{ width: `${percentage}%` }}
        ></div>
      </div>
    </div>
  );

  const SkillBar = ({ skill, level }: { skill: string; level: number }) => (
    <div className="mb-2">
      <div className="flex justify-between mb-1">
        <span className="text-sm font-medium text-gray-700">{skill}</span>
      </div>
      <div className="w-full bg-gray-200 rounded-full h-1.5">
        <div 
          className="bg-blue-800 h-1.5 rounded-full"
          style={{ width: `${level}%` }}
        ></div>
      </div>
    </div>
  );

  return (
    <div className="min-h-screen bg-gray-50 py-8 px-4">
      <div className="max-w-6xl mx-auto bg-white shadow-2xl rounded-lg overflow-hidden">
        
        {/* En-tête avec nom et titre */}
        <div className="bg-blue-800 text-white p-8">
          <div className="flex items-center space-x-6">
            <div className="w-32 h-32 rounded-full border-4 border-white overflow-hidden flex-shrink-0 bg-gray-300">
              <div className="w-full h-full bg-gradient-to-br from-blue-400 to-blue-600 flex items-center justify-center">
                <User size={48} className="text-white" />
              </div>
            </div>
            <div>
              <h1 className="text-4xl font-bold mb-2">NDONGO MBENEMBE</h1>
              <h1 className="text-4xl font-bold mb-4">BRONDONE JEAN</h1>
              <h2 className="text-2xl font-light bg-white/10 px-4 py-2 rounded-full inline-block">
                LOGISTICIEN – TRANSPORT & SUPPLY CHAIN
              </h2>
            </div>
          </div>
        </div>

        <div className="flex flex-col lg:flex-row">
          {/* Colonne gauche */}
          <div className="lg:w-1/3 bg-gray-50 p-8">
            
            {/* Contact */}
            <div className="mb-8">
              <h3 className="text-xl font-bold text-blue-800 mb-4 border-b-2 border-blue-800 pb-2">
                CONTACT
              </h3>
              <div className="space-y-3">
                <div className="flex items-center space-x-3">
                  <Phone size={18} className="text-blue-800" />
                  <div>
                    <div className="text-sm font-medium">656224624</div>
                    <div className="text-sm">680810806</div>
                  </div>
                </div>
                <div className="flex items-center space-x-3">
                  <Mail size={18} className="text-blue-800" />
                  <span className="text-sm">brondondendongo@gmail.com</span>
                </div>
                <div className="flex items-center space-x-3">
                  <MapPin size={18} className="text-blue-800" />
                  <span className="text-sm">Douala & Yaoundé, Cameroun</span>
                </div>
                <div className="flex items-center space-x-3">
                  <Calendar size={18} className="text-blue-800" />
                  <span className="text-sm">08/06/1998, Yaoundé</span>
                </div>
              </div>
            </div>

            {/* Langues */}
            <div className="mb-8">
              <h3 className="text-xl font-bold text-blue-800 mb-4 border-b-2 border-blue-800 pb-2">
                LANGUES
              </h3>
              <div className="space-y-4">
                <div>
                  <h4 className="font-semibold mb-2">Anglais</h4>
                  <ProgressBar label="Oral" percentage={92} />
                  <ProgressBar label="Écrit" percentage={94} />
                </div>
                <div>
                  <h4 className="font-semibold mb-2">Français</h4>
                  <ProgressBar label="Oral" percentage={87} />
                  <ProgressBar label="Écrit" percentage={88} />
                </div>
              </div>
            </div>

            {/* Compétences techniques */}
            <div className="mb-8">
              <h3 className="text-xl font-bold text-blue-800 mb-4 border-b-2 border-blue-800 pb-2">
                COMPÉTENCES TECHNIQUES
              </h3>
              <div className="space-y-3">
                <SkillBar skill="Pack Office" level={95} />
                <SkillBar skill="GPS & Logistique" level={90} />
                <SkillBar skill="Canva & Design" level={85} />
                <SkillBar skill="Intelligence Artificielle" level={80} />
                <SkillBar skill="Gestion de flotte" level={88} />
              </div>
              <div className="mt-4 flex items-center space-x-2">
                <Award size={16} className="text-blue-800" />
                <span className="text-sm font-medium">Permis de conduire catégorie B (2023)</span>
              </div>
            </div>

            {/* Qualités personnelles */}
            <div>
              <h3 className="text-xl font-bold text-blue-800 mb-4 border-b-2 border-blue-800 pb-2">
                QUALITÉS PERSONNELLES
              </h3>
              <div className="grid grid-cols-2 gap-3">
                <div className="flex items-center space-x-2">
                  <Target size={16} className="text-blue-800" />
                  <span className="text-sm">Organisation</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Users size={16} className="text-blue-800" />
                  <span className="text-sm">Esprit d'équipe</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Zap size={16} className="text-blue-800" />
                  <span className="text-sm">Proactivité</span>
                </div>
                <div className="flex items-center space-x-2">
                  <Settings size={16} className="text-blue-800" />
                  <span className="text-sm">Polyvalence</span>
                </div>
              </div>
            </div>
          </div>

          {/* Colonne droite */}
          <div className="lg:w-2/3 p-8">
            
            {/* Présentation */}
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-blue-800 mb-4 border-b-2 border-blue-800 pb-2">
                PROFIL PROFESSIONNEL
              </h3>
              <p className="text-gray-700 leading-relaxed text-justify">
                Jeune professionnel de 27 ans passionné par la logistique, je possède une solide expérience dans la gestion du transport, de la chaîne d'approvisionnement et du suivi opérationnel grâce à des stages, des emplois variés et une formation complète. Rigoureux, dynamique et flexible, je m'investis pleinement dans chaque mission pour optimiser les flux et garantir l'atteinte des objectifs grâce à l'esprit d'équipe et à l'amélioration continue. Motivé à participer à la transformation digitale et durable du secteur, je vise l'excellence opérationnelle.
              </p>
            </div>

            {/* Formation */}
            <div className="mb-8">
              <h3 className="text-2xl font-bold text-blue-800 mb-6 border-b-2 border-blue-800 pb-2 flex items-center">
                <GraduationCap size={24} className="mr-2" />
                FORMATION
              </h3>
              <div className="space-y-6">
                <div className="border-l-4 border-blue-800 pl-6">
                  <div className="mb-2">
                    <h4 className="text-lg font-bold text-gray-800">HND Transport & Logistique</h4>
                    <div className="text-blue-800 font-semibold">AZIMUT HIGHER INSTITUTE, Yaoundé</div>
                    <div className="text-gray-600 text-sm">2021</div>
                  </div>
                  <ul className="list-disc list-inside text-gray-700 text-sm space-y-1">
                    <li>Gestion de flotte, optimisation logistique, gestion des stocks, GPS avancés</li>
                    <li>Projet : Optimisation de la chaîne logistique d'une PME locale</li>
                  </ul>
                </div>
                
                <div className="border-l-4 border-gray-300 pl-6">
                  <div className="mb-2">
                    <h4 className="text-lg font-semibold text-gray-800">GCE A/L</h4>
                    <div className="text-gray-600 font-medium">ATLANTA BILINGUAL COMMERCIAL HIGH SCHOOL</div>
                    <div className="text-gray-600 text-sm">2018</div>
                  </div>
                </div>

                <div className="border-l-4 border-gray-300 pl-6">
                  <div className="mb-2">
                    <h4 className="text-lg font-semibold text-gray-800">GCE O/L</h4>
                    <div className="text-gray-600 font-medium">CHRIST THE KING COLLEGE "Buea Diocese"</div>
                    <div className="text-gray-600 text-sm">2016</div>
                  </div>
                  <p className="text-gray-700 text-sm">
                    <span className="font-medium">Préfet de l'établissement (2017)</span> – Coordination d'une équipe de 30 élèves
                  </p>
                </div>
              </div>
            </div>

            {/* Expériences */}
            <div>
              <h3 className="text-2xl font-bold text-blue-800 mb-6 border-b-2 border-blue-800 pb-2 flex items-center">
                <Briefcase size={24} className="mr-2" />
                EXPÉRIENCES PROFESSIONNELLES
              </h3>
              <div className="space-y-8">
                
                <div className="border-l-4 border-blue-800 pl-6">
                  <div className="mb-3">
                    <h4 className="text-lg font-bold text-gray-800">Moniteur Indépendant</h4>
                    <div className="text-blue-800 font-semibold">Organisation Mondiale de la Santé (OMS)</div>
                    <div className="text-gray-600 text-sm">Missions entre Septembre 2021 et Juillet 2024</div>
                  </div>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 text-sm">
                    <li>Vérification terrain des campagnes de vaccination et de surveillance épidémiologique (polio, rougeole, choléra, COVID-19)</li>
                    <li>Détection des insuffisances et mise en place de solutions correctives immédiates</li>
                    <li>Collecte et analyse de données pour améliorer l'impact des campagnes</li>
                    <li>Rédaction de rapports stratégiques avec recommandations pour les futures interventions</li>
                  </ul>
                </div>

                <div className="border-l-4 border-gray-300 pl-6">
                  <div className="mb-3">
                    <h4 className="text-lg font-semibold text-gray-800">Responsable Service Logistique</h4>
                    <div className="text-gray-600 font-medium">Likini Open Air Space</div>
                    <div className="text-gray-600 text-sm">Septembre 2022 – Février 2023</div>
                  </div>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 text-sm">
                    <li>Supervision événements >2000 visiteurs, coordination transport, stocks, sécurité renforcée</li>
                  </ul>
                </div>

                <div className="border-l-4 border-gray-300 pl-6">
                  <div className="mb-3">
                    <h4 className="text-lg font-semibold text-gray-800">Sales Agent</h4>
                    <div className="text-gray-600 font-medium">Elkatan & Co</div>
                    <div className="text-gray-600 text-sm">Septembre 2021 – Juillet 2022</div>
                  </div>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 text-sm">
                    <li>Négociation contrats B2B, digitalisation CRM, mise en place d'indicateurs de performance</li>
                  </ul>
                </div>

                <div className="border-l-4 border-gray-300 pl-6">
                  <div className="mb-3">
                    <h4 className="text-lg font-semibold text-gray-800">Stagiaire</h4>
                    <div className="text-gray-600 font-medium">Petro Service et Logistique (PSL), Douala</div>
                    <div className="text-gray-600 text-sm">Juillet – Septembre 2019</div>
                  </div>
                  <ul className="list-disc list-inside text-gray-700 space-y-1 text-sm">
                    <li>Gestion flotte 15 véhicules, suivi digital GPS, optimisation approvisionnement (-20% ruptures)</li>
                  </ul>
                </div>

              </div>
            </div>
          </div>
        </div>
      </div>
    </div>
  );
}

export default App;